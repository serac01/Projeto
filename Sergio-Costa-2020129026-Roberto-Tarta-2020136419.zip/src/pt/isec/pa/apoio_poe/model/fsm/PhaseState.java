package pt.isec.pa.apoio_poe.model.fsm;

public enum PhaseState {
    PHASE_1, PHASE_2, PHASE_3, PHASE_4, PHASE_5
}
